function encrypt(key,data) {
    return data
}
function decrypt(key,data){
    return data
}

exports.encrypt = encrypt
exports.decrypt = decrypt